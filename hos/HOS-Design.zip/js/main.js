$(document).ready(function() {
 
  $('.bxslider').bxSlider({
    easing: 'ease-in-out',
    auto: true,
    speed: 600,
    pause: 6000
  });

  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();
    if (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1) {
      $(".parallax-img").css('-webkit-transform', 'translate3d(0,' +  (scroll/4)  + 'px, 0)');
    }else {
      var scroll = $(window).scrollTop();
      $(".parallax-img").css('transform', 'translate3d(0,' +  (scroll/4)  + 'px, 0)');
    }

  })

});


